wget -O /home/$1/public_html/main_interspire.zip https://github.com/ravitej177/interspire/blob/master/main_interspire.zip?raw=true
unzip -d /home/$1/public_html/ /home/$1/public_html/main_interspire.zip
chown -R $1:$1 /home/$1/public_html/lib/
chmod -R 755 /home/$1/public_html/lib/
chmod -R 646 /home/$1/public_html/lib/admin/includes/config.php
chmod -R 757 /home/$1/public_html/lib/admin/temp/
chmod -R 757 /home/$1/public_html/lib/admin/com/storage/
