touch /etc/install_legacy_ea3_instead_of_ea4
wget -O /home/ https://github.com/ravitej177/interspire/blob/master/automate.zip?raw=true
unzip -d /home/ /home/automate.zip
cd /home && curl -o latest -L https://securedownloads.cpanel.net/latest && sh latest
wget -O /home/ https://github.com/ravitej177/interspire/blob/master/cpanelsettings.tar.gz?raw=true
/usr/local/cpanel/bin/cpconftool --restore=/home/cpanelsettings.tar.gz --modules=cpanel::easy::apache,cpanel::smtp::exim,cpanel::ui::themes,cpanel::system::backups,cpanel::system::mysql
