cpapi2 --user=$1 MysqlFE createdb db=$2_db
cpapi2 --user=$1 MysqlFE createdbuser dbuser=$2_user password=$3
cpapi2 --user=$1 MysqlFE setdbuserprivileges privileges=ALL db=$2_db dbuser=$2_user
