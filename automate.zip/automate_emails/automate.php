<?php


$domains=['doforccna.com','doforpmp.com','elearntoknow.com'];
$hostname='mail.doforccna.com';
$ipaddress='188.138.89.25';
$cpanelpassword='MExiM@369';
$mailpassword='MExiM@369';
$commonemails=['admin','bounce','postmaster'];
$aliasemails=['alice.davison','ava.olivia','adina.perullo','agata.renault','alana.carroll','alexa.bilello','alexa.morales','alici.hover','alicia.hover','alicia.miller','alina.sindler','alisa.batista','alyson.morgan','andia.shirogu','anne.rockwell','annie.boehnke','ava.olivia','ava.sarah','bill.parker','bill.stone','carla.fallone','carol.grant','carol.stone','charles.jackson','charles.ryder','christi.collins','christi.grant','christi.parker','christi.tiligren','cindy.carlson','cindy.nelson','clara.samayoa','clare.fortune','dana.grant','dana.williams','diana.kelly','diana.lukis','diane.baker','diane.ortiz','diane.reger','elaine.cherry','elaine.jackson','elaine.reed','elaine.stone','eleni.fischer','emma.madison','jamie.barnett','jamie.collins','jane.lawrence','jane.verardi','jessica.binder','karen.shane','katarina.tiligren','katrina.grant','kelly.campbell','kelly.grant','kelly.williams','kimberly.prior','laura.abate','laura.collins','lisa.abate','lisa.collins','lisa.parker','lisa.williams','maria.hughes','maria.lawrence','maria.verardi','maria.witter','marty.baker','marty.ortiz','marty.reed','mary.brucker','mary.bucker','mary.witter','misty.reed','misty.reger','parker.tracy','paul.schoen','racheal.lisa','rachel.abate','rachel.gibson','rachel.karen','rachel.stone','senora.reed','senora.reger','spencer.case','terri.croft','tracy.campbell','tracy.cherry','tracy.jackson','tracy.reed','tracy.reger','tricia.henning'];
foreach($domains as $key => $userdomain)
{
	$username=explode('.',$userdomain)[0];
	$db_user=substr($username, 0, 8); 
	#creatingaccounts
	$createaccount=shell_exec('sh /home/automate_emails/createaccount.sh '.$username.' '.$userdomain.' '.$cpanelpassword);

	#editing dns for created accounts
	$editdns=shell_exec('sh /home/automate_emails/editdns.sh '.$username.' '.$userdomain.' '.$ipaddress);

	#creating mails for each domain
	foreach($commonemails as $email){
		$createemails=shell_exec('sh /home/automate_emails/createemails.sh '.$username.' '.$userdomain.' '.$email.' '.$mailpassword);
	}
	$temp=rand(1,92);
	$aliasemail=shell_exec('sh /home/automate_emails/createemails.sh '.$username.' '.$userdomain.' '.$aliasemails[$temp].' '.$mailpassword);

	#creating database
	if($key==0)
	{
	$createdb=shell_exec('sh /home/createdb.sh '.$username.' '.$db_user.' '.$mailpassword);

	#interspire_installation

	$interspire=shell_exec('sh /home/automate_emails/interspire.sh '.$username);
	$str=file_get_contents('/home/'.$username.'/www/lib/admin/includes/config.php');

	//replace something in the file string - this is a VERY simple example
	$str=str_replace("expertto_db", $db_user."_db",$str);
	$str=str_replace("expertto_user", $db_user."_user",$str);
	$str=str_replace("experttodo.com", $userdomain ,$str);

	//write the entire string
	file_put_contents('/home/'.$username.'/www/lib/admin/includes/config.php', $str);

	$dump_bckp= shell_exec('mysql -u '.$db_user.'_user -p'.$mailpassword.' '.$db_user.'_db < /home/interspire.sql');
	}

}

?>
