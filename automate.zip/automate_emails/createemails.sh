cpapi2 --user=$1 Email addpop domain=$2 email=$3 password=$4 quota=1000
