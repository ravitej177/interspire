cpapi2 --user=$1 ZoneEdit edit_zone_record Line=19 domain=$2 name=mail type=A address=$3 ttl=14400 class=IN
cpapi2 --user=$1 ZoneEdit edit_zone_record Line=20 domain=$2 name=ftp type=A address=$3 ttl=14400 class=IN
