<?php

/**
* Language file for jobs_autoresponders file.
* This is here as a placeholder only.
* See the autoresponders.php file and the language.php file for all autoresponder language variables.
*
* @see autoresponders.php
* @see language.php
*
* @package SendStudio
* @subpackage Language
*/

?>
