<?php
/**
* Language file variables for the manage account area.
* These are in the Users file.
*
* @see GetLang
*
* @version     $Id: manageaccount.php,v 1.3 2007/11/01 02:48:20 chris Exp $
* @author Chris <chris@interspire.com>
*
* @package SendStudio
* @subpackage Language
*/

/**
* ManageAccounts language variables are in the Users file.
*/

?>
