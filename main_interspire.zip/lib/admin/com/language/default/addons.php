<?php

/**
 * This file is a placeholder only.
 * The addons have their own language files, found in the
 * addons/{addonid}/language/
 * folder.
 *
 * Use the addon language files to make the necessary changes.
 *
 * @package SendStudio
 * @subpackage Language
 */
